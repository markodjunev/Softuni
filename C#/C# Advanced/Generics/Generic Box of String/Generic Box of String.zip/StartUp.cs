﻿using System;

namespace Generic_Box_of_String
{
    class Program
    {
        static void Main()
        {
            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                var input = Console.ReadLine();
                var item = new Box<string>(input);

                Console.WriteLine(item);

            }



        }
    }
}