﻿namespace P03_SalesDatabase.Data
{
    public static class Configuration
    {
        internal static string ConnectionString = @"Server=PC-785\SQLEXPRESS01;" +
                                                  "Database=SalesDatabase;" +
                                                  "Integrated Security=true;";
    }
}