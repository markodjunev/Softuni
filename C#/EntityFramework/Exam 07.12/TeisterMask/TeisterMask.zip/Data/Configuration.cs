﻿namespace TeisterMask.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=PC-785\SQLEXPRESS01;Database=TeisterMask;Trusted_Connection=True";
    }
}
