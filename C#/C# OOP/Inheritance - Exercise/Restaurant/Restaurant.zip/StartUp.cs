﻿namespace Restaurant
{
    using Restaurant.Foods.Dessert;
    using Restaurant.Foods.MainDish;
    using Restaurant.Foods.Starter;
    using Restaurant.Beverages.HotBeverage;
    using Restaurant.Beverages.ColdBeverage;

    public class StartUp
    {
        public static void Main(string[] args)
        {

        }
    }
}